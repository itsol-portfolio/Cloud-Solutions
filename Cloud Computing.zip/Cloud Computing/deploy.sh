#!/bin/bash
echo "Starting sample cloud deployment..."
echo "Building Docker image..."
docker build -t sample-cloud-app .
echo "Deploying container..."
docker run -d -p 8080:80 sample-cloud-app
echo "Deployment complete!"
